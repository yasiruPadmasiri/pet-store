package com.example.petstore;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 */
@ApplicationPath("/")
public class PetstoreRestApplication extends Application {
}
